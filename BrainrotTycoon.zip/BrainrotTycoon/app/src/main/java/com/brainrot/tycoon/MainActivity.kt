package com.brainrot.tycoon

import android.content.SharedPreferences
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlin.math.floor
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sqrt
import kotlin.random.Random

val Purple = Color(0xFF9B5DE5); val Green = Color(0xFF00F5A0); val Orange = Color(0xFFFF9F1C)
val Bg = Color(0xFF0E0B16); val CardC = Color(0xFF1B1530); val Gray = Color(0xFFAAA3C2)

fun fmt(v: Double): String {
    if (v < 1000) return if (v < 10) String.format("%.1f", v) else v.toLong().toString()
    val s = listOf("K", "M", "B", "T", "Qa", "Qi", "Sx", "Sp", "Oc", "No")
    var x = v; var i = -1
    while (x >= 1000 && i < s.size - 1) { x /= 1000; i++ }
    return String.format("%.2f%s", x, s[i])
}

class Biz(val name: String, val icon: String, val company: String, val desc: String, val base: Double, val inc: Double)
val B = listOf(
    Biz("Мемная лавка", "🏪", "ИП «Лавка»", "Продаём мемы на вес. Свежие, хрустящие.", 15.0, 0.5),
    Biz("Фабрика Brainrot", "🧠", "ООО «БРАИНРОТ»", "Конвейер по производству гниения мозга.", 150.0, 4.0),
    Biz("Завод скибиди", "🚽", "ООО «ТМЫВ ДЕНЕГ»", "Смываем деньги — а они возвращаются.", 2000.0, 30.0),
    Biz("Империя Абанюна", "👑", "ООО «АБАНЮНА»", "Абанюна абанюна — и всё в шоколаде.", 30000.0, 240.0),
    Biz("Корпорация Дринк Фор Ми", "🥤", "ООО «ДРИНК ФОР МИ»", "Выпей за меня, а я посчитаю прибыль.", 5e5, 2000.0),
    Biz("Межгалактический холдинг", "🛸", "ООО «МАГАД»", "Мемы доставляются на три галактики вперёд.", 1e7, 18000.0),
    Biz("Стартап СПЕРМО", "🏊", "ООО «СПЕРМО»", "Плывём к успеху быстрее всех. Инвесторы в восторге.", 2e8, 150000.0)
)
val CHARS = listOf("Шлёпа", "Бульбулятор", "Скибидон", "Абанюша", "Дринкус", "Магадон", "Плыв")
val CHAR_ICONS = listOf("🐱", "🐸", "🗿", "👑", "🧃", "👾", "🐟")
val SKINS = listOf(Triple("🪙", 0, "Классика"), Triple("💎", 15, "Алмаз"), Triple("🍕", 40, "Пицца"),
    Triple("🤡", 100, "Клоун"), Triple("👽", -1, "Престиж-скин"))
val EVENTS = listOf(
    Triple("🚽 СКИБИДИ-БУМ! Доход x2", 2.0, 20), Triple("🔥 СИГМА-ПОТОК! Доход x3", 3.0, 15),
    Triple("🤑 Налоговая спит! Доход x2", 2.0, 25), Triple("🧠 Мозг гниёт на полную! x5", 5.0, 10)
)
class Ach(val id: String, val t: String, val d: String, val secret: Boolean, val c: (G) -> Boolean)
val ACH = listOf(
    Ach("first", "Первый тык", "Кликни монету", false) { it.clicks >= 1 },
    Ach("c100", "Кликер-новичок", "100 кликов", false) { it.clicks >= 100 },
    Ach("c2000", "Палец-терминатор", "2000 кликов", false) { it.clicks >= 2000 },
    Ach("m1k", "Тысячник", "Заработай 1K", false) { it.total >= 1e3 },
    Ach("m1m", "Миллионер", "Заработай 1M", false) { it.total >= 1e6 },
    Ach("m1b", "Миллиардер", "Заработай 1B", false) { it.total >= 1e9 },
    Ach("m1t", "Триллионер", "Заработай 1T", false) { it.total >= 1e12 },
    Ach("b25", "Бизнесмен", "25 предприятий", false) { it.owned.sum() >= 25 },
    Ach("pres", "Новая жизнь", "Первое перерождение", false) { it.prestige >= 1 },
    Ach("s777", "???", "Секрет: 777 кликов", true) { it.clicks >= 777 },
    Ach("sall", "???", "Секрет: владей всеми компаниями", true) { g -> g.owned.all { it > 0 } }
)

class G(val sp: SharedPreferences) {
    var money by mutableStateOf(0.0); var coins by mutableStateOf(0.0)
    var run by mutableStateOf(0.0); var total by mutableStateOf(0.0)
    var clicks by mutableStateOf(0L)
    var clickLvl by mutableStateOf(0); var autoLvl by mutableStateOf(0); var critLvl by mutableStateOf(0)
    var prestige by mutableStateOf(0); var perm by mutableStateOf(0)
    var lastDaily by mutableStateOf(0L); var streak by mutableStateOf(0)
    var skin by mutableStateOf(0)
    var boostUntil by mutableStateOf(0L); var boostMul by mutableStateOf(1.0)
    var eventUntil by mutableStateOf(0L); var eventMul by mutableStateOf(1.0); var eventText by mutableStateOf("")
    var nextEvent = System.currentTimeMillis() + 30000
    var nowMs by mutableStateOf(System.currentTimeMillis())
    var msg by mutableStateOf(""); var msgUntil by mutableStateOf(0L)
    val owned = mutableStateListOf<Int>(); val upg = mutableStateListOf<Int>()
    val ach = mutableStateListOf<String>(); val skins = mutableStateListOf(0)
    val board = mutableStateListOf<Double>()

    fun gmul(): Double {
        var m = 1 + 0.25 * prestige + 0.25 * perm
        if (nowMs < boostUntil) m *= boostMul
        if (nowMs < eventUntil) m *= eventMul
        return m
    }
    fun bizCost(i: Int) = B[i].base * 1.15.pow(owned[i].toDouble())
    fun upCost(i: Int) = B[i].base * 25 * 8.0.pow(upg[i].toDouble())
    fun bizIps(i: Int) = owned[i] * B[i].inc * 2.0.pow(upg[i].toDouble()) * gmul()
    fun clickPower() = (1 + clickLvl) * 1.07.pow(clickLvl.toDouble()) * (1 + 0.5 * prestige)
    fun ips() = B.indices.sumOf { bizIps(it) } + autoLvl * 0.2 * clickPower() * gmul()
    fun critChance() = 0.05 + 0.03 * critLvl
    fun clickCost() = 10 * 1.6.pow(clickLvl.toDouble())
    fun autoCost() = 100 * 1.8.pow(autoLvl.toDouble())
    fun critCost() = 500 * 2.5.pow(critLvl.toDouble())
    fun earn(x: Double) { money += x; run += x; total += x }
    fun toast(s: String) { msg = s; msgUntil = nowMs + 3500 }

    fun click(): Pair<Double, Boolean> {
        val crit = Random.nextDouble() < critChance()
        val a = clickPower() * gmul() * (if (crit) 5 else 1)
        earn(a); clicks++
        return Pair(a, crit)
    }
    fun buy(i: Int) { val c = bizCost(i); if (money >= c) { money -= c; owned[i] = owned[i] + 1 } }
    fun upgrade(i: Int) { val c = upCost(i); if (owned[i] > 0 && upg[i] < 3 && money >= c) { money -= c; upg[i] = upg[i] + 1 } }
    fun prestigeGain() = floor(sqrt(run / 1e7)).toInt()
    fun doPrestige() {
        val g = prestigeGain(); if (g < 1) return
        coins += g; prestige++
        board.add(run); board.sortDescending(); while (board.size > 5) board.removeAt(board.size - 1)
        money = 0.0; run = 0.0; clickLvl = 0; autoLvl = 0; critLvl = 0
        for (i in B.indices) { owned[i] = 0; upg[i] = 0 }
        boostUntil = 0; save()
    }
    fun canDaily() = nowMs - lastDaily >= 86400000L
    fun claimDaily() {
        if (!canDaily()) return
        streak = if (nowMs - lastDaily < 172800000L) min(streak + 1, 7) else 1
        val r = ips() * 300 + 100
        coins += streak; earn(r); lastDaily = nowMs
        toast("Награда: +${fmt(r)} и +$streak BC (серия $streak)")
    }
    fun tick(dt: Double, now: Long) {
        nowMs = now
        earn(ips() * dt)
        if (now > nextEvent) {
            val e = EVENTS.random(); eventText = e.first; eventMul = e.second
            eventUntil = now + e.third * 1000L; nextEvent = now + Random.nextLong(45000, 90000)
        }
        for (a in ACH) if (!ach.contains(a.id) && a.c(this)) {
            ach.add(a.id); coins += 1; toast("🏆 ${if (a.secret) "Секрет: " else ""}${a.t} (+1 BC)")
        }
    }

    private fun d(k: String) = sp.getString(k, null)?.toDoubleOrNull() ?: 0.0
    private fun ints(k: String) = (sp.getString(k, "") ?: "").split(",").mapNotNull { it.toIntOrNull() }
    fun load() {
        money = d("money"); coins = d("coins"); run = d("run"); total = d("total")
        clicks = sp.getLong("clicks", 0); clickLvl = sp.getInt("cl", 0); autoLvl = sp.getInt("al", 0)
        critLvl = sp.getInt("crl", 0); prestige = sp.getInt("pr", 0); perm = sp.getInt("perm", 0)
        lastDaily = sp.getLong("daily", 0); streak = sp.getInt("streak", 0); skin = sp.getInt("skin", 0)
        val o = ints("owned"); val u = ints("upg")
        owned.clear(); upg.clear()
        for (i in B.indices) { owned.add(o.getOrElse(i) { 0 }); upg.add(u.getOrElse(i) { 0 }) }
        ach.clear(); ach.addAll((sp.getString("ach", "") ?: "").split(",").filter { it.isNotEmpty() })
        skins.clear(); skins.addAll(ints("skins").ifEmpty { listOf(0) })
        board.clear(); board.addAll((sp.getString("board", "") ?: "").split(",").mapNotNull { it.toDoubleOrNull() })
        val t = sp.getLong("t", 0)
        if (t > 0) {
            val sec = min((System.currentTimeMillis() - t) / 1000.0, 7200.0)
            val r = ips() * sec * 0.5
            if (r > 1) { earn(r); toast("С возвращением! Пока тебя не было: +${fmt(r)}") }
        }
    }
    fun save() {
        sp.edit().putString("money", money.toString()).putString("coins", coins.toString())
            .putString("run", run.toString()).putString("total", total.toString())
            .putLong("clicks", clicks).putInt("cl", clickLvl).putInt("al", autoLvl).putInt("crl", critLvl)
            .putInt("pr", prestige).putInt("perm", perm).putLong("daily", lastDaily).putInt("streak", streak)
            .putInt("skin", skin).putString("owned", owned.joinToString(",")).putString("upg", upg.joinToString(","))
            .putString("ach", ach.joinToString(",")).putString("skins", skins.joinToString(","))
            .putString("board", board.joinToString(",")).putLong("t", System.currentTimeMillis()).apply()
    }
}

class MainActivity : ComponentActivity() {
    lateinit var g: G
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        g = G(getSharedPreferences("save", MODE_PRIVATE)); g.load()
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Purple, secondary = Green, tertiary = Orange,
                background = Bg, surface = CardC, onBackground = Color.White, onSurface = Color.White)) { App(g) }
        }
    }
    override fun onPause() { super.onPause(); g.save() }
    override fun onStop() { super.onStop(); g.save() }
}

@Composable fun App(g: G) {
    var tab by remember { mutableStateOf(0) }
    LaunchedEffect(Unit) {
        var last = System.currentTimeMillis(); var saveT = last
        while (true) {
            delay(100)
            val now = System.currentTimeMillis()
            g.tick(min((now - last) / 1000.0, 1.0), now); last = now
            if (now - saveT > 5000) { g.save(); saveT = now }
        }
    }
    Scaffold(containerColor = Bg, bottomBar = {
        NavigationBar(containerColor = CardC) {
            listOf("🏠" to "Главная", "🏢" to "Бизнес", "⚡" to "Улучшения", "🛒" to "Магазин", "👤" to "Профиль")
                .forEachIndexed { i, p ->
                    NavigationBarItem(selected = tab == i, onClick = { tab = i },
                        icon = { Text(p.first, fontSize = 22.sp) }, label = { Text(p.second, fontSize = 10.sp) })
                }
        }
    }) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().background(Bg)) {
            Hud(g)
            when (tab) { 0 -> Home(g); 1 -> BizTab(g); 2 -> UpTab(g); 3 -> Shop(g); else -> Profile(g) }
        }
    }
}

@Composable fun Hud(g: G) {
    Column(Modifier.fillMaxWidth().background(CardC).padding(12.dp, 8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("💰 ${fmt(g.money)}", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Green, modifier = Modifier.weight(1f))
            Text("🧠 ${fmt(g.coins)} BC", fontSize = 16.sp, color = Orange, fontWeight = FontWeight.Bold)
        }
        Text("+${fmt(g.ips())}/сек  •  множитель x${String.format("%.2f", g.gmul())}", color = Gray, fontSize = 12.sp)
    }
}

class FN(val id: Long, val t: String, val x: Float, val y: Float, val crit: Boolean)

@Composable fun FloatText(f: FN, onDone: () -> Unit) {
    val a = remember { Animatable(0f) }
    LaunchedEffect(Unit) { a.animateTo(1f, tween(800)); onDone() }
    Text(f.t, color = if (f.crit) Orange else Green, fontWeight = FontWeight.Bold,
        fontSize = if (f.crit) 30.sp else 20.sp,
        modifier = Modifier.offset { IntOffset(f.x.toInt(), (f.y - a.value * 220f).toInt()) }.alpha(1f - a.value))
}

@Composable fun Home(g: G) {
    val haptic = LocalHapticFeedback.current
    var pressed by remember { mutableStateOf(false) }
    val sc by animateFloatAsState(if (pressed) 0.88f else 1f, spring(dampingRatio = 0.4f), label = "s")
    val floats = remember { mutableStateListOf<FN>() }
    var nid by remember { mutableStateOf(0L) }
    Column(Modifier.fillMaxSize().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        if (g.nowMs < g.eventUntil)
            Text("${g.eventText} (${(g.eventUntil - g.nowMs) / 1000}с)", color = Color.Black, fontWeight = FontWeight.Bold,
                modifier = Modifier.fillMaxWidth().background(Orange, RoundedCornerShape(12.dp)).padding(10.dp))
        if (g.nowMs < g.msgUntil)
            Text(g.msg, color = Green, modifier = Modifier.padding(top = 8.dp))
        Spacer(Modifier.weight(1f))
        Box(Modifier.size(230.dp).scale(sc)
            .background(Brush.radialGradient(listOf(Orange, Purple)), CircleShape)
            .pointerInput(Unit) {
                detectTapGestures(onPress = { pressed = true; tryAwaitRelease(); pressed = false },
                    onTap = { off ->
                        val r = g.click()
                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                        if (floats.size > 12) floats.removeAt(0)
                        floats.add(FN(nid++, (if (r.second) "КРИТ! " else "+") + fmt(r.first), off.x - 30f, off.y, r.second))
                    })
            }, contentAlignment = Alignment.Center) {
            Text(SKINS[g.skin].first, fontSize = 110.sp)
            floats.toList().forEach { f -> key(f.id) { Box(Modifier.align(Alignment.TopStart)) { FloatText(f) { floats.remove(f) } } } }
        }
        Spacer(Modifier.height(12.dp))
        Text("+${fmt(g.clickPower() * g.gmul())} за клик • крит ${(g.critChance() * 100).toInt()}% (x5)", color = Gray, fontSize = 13.sp)
        Spacer(Modifier.weight(1f))
        Button(onClick = { g.claimDaily() }, enabled = g.canDaily(), modifier = Modifier.fillMaxWidth().height(52.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Green, contentColor = Color.Black)) {
            Text(if (g.canDaily()) "🎁 Ежедневная награда" else "🎁 Награда уже получена — приходи завтра", fontWeight = FontWeight.Bold)
        }
    }
}

@Composable fun Item(icon: String, title: String, sub: String, content: @Composable ColumnScope.() -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = CardC), shape = RoundedCornerShape(18.dp),
        modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp).animateContentSize()) {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(icon, fontSize = 38.sp); Spacer(Modifier.width(12.dp))
                Column { Text(title, fontWeight = FontWeight.Bold, fontSize = 16.sp); Text(sub, color = Gray, fontSize = 12.sp) }
            }
            Spacer(Modifier.height(8.dp)); content()
        }
    }
}

@Composable fun BizTab(g: G) {
    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 12.dp)) {
        items(B.size) { i ->
            val b = B[i]
            Item(b.icon, b.name, "${b.company} — ${b.desc}") {
                Text("Куплено: ${g.owned[i]}  •  Ур. ${g.upg[i]}/3  •  +${fmt(g.bizIps(i))}/с", color = Green, fontSize = 13.sp)
                Spacer(Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { g.buy(i) }, enabled = g.money >= g.bizCost(i), modifier = Modifier.weight(1f)) {
                        Text("Купить ${fmt(g.bizCost(i))}", fontSize = 12.sp) }
                    Button(onClick = { g.upgrade(i) }, enabled = g.owned[i] > 0 && g.upg[i] < 3 && g.money >= g.upCost(i),
                        colors = ButtonDefaults.buttonColors(containerColor = Orange, contentColor = Color.Black),
                        modifier = Modifier.weight(1f)) {
                        Text(if (g.upg[i] >= 3) "МАКС" else "x2 доход ${fmt(g.upCost(i))}", fontSize = 12.sp) }
                }
            }
        }
    }
}

@Composable fun UpTab(g: G) {
    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 12.dp)) {
        item {
            Item("👆", "Сила клика (ур. ${g.clickLvl})", "Сейчас: ${fmt(g.clickPower())} за клик") {
                Button(onClick = { if (g.money >= g.clickCost()) { g.money -= g.clickCost(); g.clickLvl++ } },
                    enabled = g.money >= g.clickCost(), modifier = Modifier.fillMaxWidth()) { Text("Улучшить ${fmt(g.clickCost())}") } }
            Item("🤖", "Автоработники (ур. ${g.autoLvl})", "Кликают сами: ${fmt(g.autoLvl * 0.2 * g.clickPower())}/с") {
                Button(onClick = { if (g.money >= g.autoCost()) { g.money -= g.autoCost(); g.autoLvl++ } },
                    enabled = g.money >= g.autoCost(), modifier = Modifier.fillMaxWidth()) { Text("Нанять ${fmt(g.autoCost())}") } }
            Item("💥", "Шанс крита (ур. ${g.critLvl}/10)", "Сейчас ${(g.critChance() * 100).toInt()}%, множитель x5") {
                Button(onClick = { if (g.money >= g.critCost()) { g.money -= g.critCost(); g.critLvl++ } },
                    enabled = g.critLvl < 10 && g.money >= g.critCost(), modifier = Modifier.fillMaxWidth()) {
                    Text(if (g.critLvl >= 10) "МАКС" else "Улучшить ${fmt(g.critCost())}") } }
        }
    }
}

@Composable fun Shop(g: G) {
    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 12.dp)) {
        item {
            Item("⏱", "Буст x2 на 2 минуты", "Временный множитель дохода") {
                Button(onClick = { if (g.coins >= 5) { g.coins -= 5; g.boostMul = 2.0; g.boostUntil = g.nowMs + 120000 } },
                    enabled = g.coins >= 5, modifier = Modifier.fillMaxWidth()) { Text("5 BC") } }
            Item("🚀", "Буст x5 на 1 минуту", "Мощный временный множитель") {
                Button(onClick = { if (g.coins >= 20) { g.coins -= 20; g.boostMul = 5.0; g.boostUntil = g.nowMs + 60000 } },
                    enabled = g.coins >= 20, modifier = Modifier.fillMaxWidth()) { Text("20 BC") } }
            val pc = 10 * 2.0.pow(g.perm.toDouble())
            Item("📈", "+25% дохода навсегда (куплено ${g.perm})", "Сохраняется после перерождения") {
                Button(onClick = { if (g.coins >= pc) { g.coins -= pc; g.perm++ } },
                    enabled = g.coins >= pc, modifier = Modifier.fillMaxWidth()) { Text("${fmt(pc)} BC") } }
            Text("Скины монеты", fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 10.dp))
            SKINS.forEachIndexed { i, s ->
                val has = g.skins.contains(i) || (s.second == -1 && g.prestige >= 1)
                Item(s.first, s.third, if (s.second == -1) "Открывается после первого перерождения" else "${s.second} BC") {
                    Button(onClick = {
                        if (has) g.skin = i
                        else if (s.second > 0 && g.coins >= s.second) { g.coins -= s.second; g.skins.add(i); g.skin = i }
                    }, enabled = has || (s.second > 0 && g.coins >= s.second), modifier = Modifier.fillMaxWidth()) {
                        Text(if (g.skin == i) "Выбран ✓" else if (has) "Выбрать" else "Купить") }
                }
            }
        }
    }
}

@Composable fun Profile(g: G) {
    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 12.dp)) {
        item {
            Item("♻️", "Перерождение (раз: ${g.prestige})", "Бонус сейчас: +${25 * g.prestige}% дохода, +${50 * g.prestige}% клика") {
                Text("За этот забег: ${fmt(g.run)}. Нужно минимум 10M.", color = Gray, fontSize = 12.sp)
                Text("Получишь: ${g.prestigeGain()} BC и +25% дохода, +50% клика", color = Green, fontSize = 13.sp)
                Button(onClick = { g.doPrestige() }, enabled = g.prestigeGain() >= 1, modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = Purple)) { Text("Переродиться") }
            }
            Item("📊", "Статистика", "") {
                Text("Клики: ${g.clicks}\nВсего заработано: ${fmt(g.total)}\nПредприятий: ${g.owned.sum()}", color = Gray)
            }
            Item("🏆", "Таблица рекордов (локальная)", "Лучшие забеги") {
                val all = (g.board.toList() + g.run).sortedDescending().take(6)
                all.forEachIndexed { i, v -> Text("${i + 1}. ${fmt(v)}${if (v == g.run) "  ← текущий" else ""}", color = if (v == g.run) Orange else Gray) }
            }
            Text("Коллекция персонажей (купи 5 предприятий)", fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp))
            CHARS.forEachIndexed { i, n ->
                val u = g.owned[i] >= 5
                Item(if (u) CHAR_ICONS[i] else "❓", if (u) n else "???", if (u) B[i].company else "Заперт") {}
            }
            Text("Достижения ${g.ach.size}/${ACH.size}", fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp))
            ACH.forEach { a ->
                val u = g.ach.contains(a.id)
                Item(if (u) "🏆" else "🔒", if (u || !a.secret) a.t else "???", if (u || !a.secret) a.d else "Секретное достижение") {}
            }
        }
    }
}
